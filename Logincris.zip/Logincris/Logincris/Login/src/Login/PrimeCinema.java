package Login;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PrimeCinema {
    private JPanel JInicio;
    private JTabbedPane tbRegistros;
    private JButton btnLogin;
    private JButton btnRegistro;
    private JFrame frame;
    private JTabbedPane tabbedPane1;
    private JLabel pelicula1;
    private JLabel pelicula2;
    private JLabel pelicula3;
    private JLabel pelicula4;
    private JLabel pelicula5;
    private JLabel lbTitulo;

    public PrimeCinema() {
        // Inicializar los componentes
        JInicio = new JPanel(new BorderLayout()); // Usamos BorderLayout para la demostración
        tbRegistros = new JTabbedPane();
        btnLogin = new JButton("Login");
        btnRegistro = new JButton("Registro");
        pelicula1 = new JLabel("Pelicula1");
        pelicula2 = new JLabel("Pelicula2");
        pelicula3 = new JLabel("Pelicula3");
        pelicula4 = new JLabel("Pelicula4");
        pelicula5 = new JLabel("Pelicula5");

        // Crear panel para mostrar las películas
        JPanel peliculasPanel = new JPanel();
        peliculasPanel.setLayout(new GridLayout(1, 5)); // Layout con 5 columnas para las películas

        // Inicializar las etiquetas de películas con imágenes
        pelicula1 = new JLabel(new ImageIcon("ruta/de/tu/imagen1.jpg"));
        pelicula2 = new JLabel(new ImageIcon("ruta/de/tu/imagen2.jpg"));
        pelicula3 = new JLabel(new ImageIcon("ruta/de/tu/imagen3.jpg"));
        pelicula4 = new JLabel(new ImageIcon("ruta/de/tu/imagen4.jpg"));
        pelicula5 = new JLabel(new ImageIcon("ruta/de/tu/imagen5.jpg"));

        // Agregar las etiquetas al panel de películas
        peliculasPanel.add(pelicula1);
        peliculasPanel.add(pelicula2);
        peliculasPanel.add(pelicula3);
        peliculasPanel.add(pelicula4);
        peliculasPanel.add(pelicula5);

        // Agregar el panel de películas al TabbedPane
        tbRegistros.addTab("Películas", peliculasPanel);

        // Agregar componentes al panel principal
        JInicio.add(tbRegistros, BorderLayout.CENTER);

        // Crear un panel con FlowLayout alineado a la derecha para los botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(btnLogin);
        buttonPanel.add(btnRegistro);
        JInicio.add(buttonPanel, BorderLayout.NORTH); // Colocar en la parte superior

        // Inicializar la ventana principal
        frame = new JFrame("PrimeCinema");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(JInicio);
        frame.setSize(800, 600); // Ajusta el tamaño de la ventana
        frame.setLocationRelativeTo(null); // Centra la ventana

        // Acción del botón Login
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Mostrar la pantalla de Login y ocultar la pantalla de PrimeCinema
                Login login = new Login();
                login.setVisible(true);
                frame.setVisible(false); // Ocultar el JFrame actual
            }
        });

        // Acción del botón Registro
        btnRegistro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Mostrar la pantalla de IngresarDatos y ocultar la pantalla de PrimeCinema
                IngresarDato ingresarDatos = new IngresarDato();
                ingresarDatos.setVisible(true);
                frame.setVisible(false); // Ocultar el JFrame actual
            }
        });
    }

    public void setVisible(boolean visible) {
        frame.setVisible(visible);
    }

    public static void main(String[] args) {
        // Crear y mostrar la ventana principal
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                PrimeCinema primeCinema = new PrimeCinema();
                primeCinema.setVisible(true);
            }
        });
    }
}
