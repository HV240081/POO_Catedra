package Login;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Sucursal {
    private JButton btningresardato;
    private JButton btnPrimeCinema;
    private JButton btnEnviar;
    private JPanel panel1;
    private JTextField txtDireccion;
    private JTextField txtGerente;
    private JTextField txtTelefono;
    private JComboBox<String> cmbSucursal;
    private JFrame frame;

    public Sucursal() {
        // Inicializar la ventana para la sucursal
        frame = new JFrame("Sucursal");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel1);
        frame.pack();
        frame.setLocationRelativeTo(null); // Centra la ventana

        // Acción del botón btningresardato
        btningresardato.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crear y mostrar la ventana IngresarDato
                IngresarDato ingresarDato = new IngresarDato();
                ingresarDato.setVisible(true);
                frame.setVisible(false); // Ocultar la ventana actual
            }
        });

        // Acción del botón btnPrimeCinema
        btnPrimeCinema.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Mostrar la ventana PrimeCinema y ocultar la ventana actual de Sucursal
                PrimeCinema primeCinema = new PrimeCinema();
                primeCinema.setVisible(true);
                frame.setVisible(false); // Ocultar la ventana actual
            }
        });

        // Acción del botón btnEnviar
        btnEnviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Verificar si todos los campos están llenos
                String direccion = txtDireccion.getText().trim();
                String gerente = txtGerente.getText().trim();
                String telefono = txtTelefono.getText().trim();
                String sucursalSeleccionada = (String) cmbSucursal.getSelectedItem();

                if (direccion.isEmpty() || gerente.isEmpty() || telefono.isEmpty() || sucursalSeleccionada == null || sucursalSeleccionada.isEmpty()) {
                    // Mostrar mensaje si algún campo está vacío
                    JOptionPane.showMessageDialog(frame, "Favor llenar todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Mostrar mensaje si todos los campos están llenos
                    JOptionPane.showMessageDialog(frame, "Datos enviados correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
    }

    public void setVisible(boolean visible) {
        frame.setVisible(visible);
    }

    public static void main(String[] args) {
        // Crear y mostrar la ventana de Sucursal
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Sucursal sucursal = new Sucursal();
                sucursal.setVisible(true);
            }
        });
    }
}
