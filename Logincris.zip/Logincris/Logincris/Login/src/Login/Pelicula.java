package Login;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pelicula {
    private JButton btnPrimeCinema;
    private JButton btningresardato;
    private JButton btnEnviar;
    private JPanel panel1;
    private JComboBox<String> cmbGenero;
    private JComboBox<String> cmbClasificacion;
    private JComboBox<String> cmbFormato;
    private JTextField txtNombrePelicula;
    private JRadioButton rbAdulto1;
    private JRadioButton rbAdulto2;
    private JRadioButton rb3eredad1;
    private JRadioButton rb3eredad2;
    private JFrame frame;

    public Pelicula() {
        // Inicializar la ventana para Pelicula
        frame = new JFrame("Pelicula");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel1);
        frame.pack();
        frame.setLocationRelativeTo(null); // Centra la ventana

        // Acción del botón btningresardato
        btningresardato.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crear y mostrar la ventana IngresarDato
                IngresarDato ingresarDato = new IngresarDato();
                ingresarDato.setVisible(true);
                frame.setVisible(false); // Ocultar la ventana actual
            }
        });

        // Acción del botón btnPrimeCinema
        btnPrimeCinema.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PrimeCinema primeCinema = new PrimeCinema();
                primeCinema.setVisible(true);
                frame.setVisible(false); // Ocultar la ventana actual
            }
        });

        // Acción del botón btnEnviar
        btnEnviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Verificar si todos los campos están llenos
                String nombrePelicula = txtNombrePelicula.getText().trim();
                String generoSeleccionado = (String) cmbGenero.getSelectedItem();
                String clasificacionSeleccionada = (String) cmbClasificacion.getSelectedItem();
                String formatoSeleccionado = (String) cmbFormato.getSelectedItem();

                // Verificar si se ha seleccionado al menos un radio button
                boolean radioSeleccionado = rbAdulto1.isSelected() || rbAdulto2.isSelected() || rb3eredad1.isSelected() || rb3eredad2.isSelected();

                if (nombrePelicula.isEmpty() || generoSeleccionado == null || generoSeleccionado.isEmpty() ||
                        clasificacionSeleccionada == null || clasificacionSeleccionada.isEmpty() ||
                        formatoSeleccionado == null || formatoSeleccionado.isEmpty() || !radioSeleccionado) {
                    // Mostrar mensaje si algún campo está vacío o no se ha seleccionado ningún radio button
                    JOptionPane.showMessageDialog(frame, "Favor llenar todos los campos y seleccionar una opción.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Mostrar mensaje si todos los campos están llenos
                    JOptionPane.showMessageDialog(frame, "Datos enviados correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // Acción del combo box cmbFormato
        cmbFormato.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String formatoSeleccionado = (String) cmbFormato.getSelectedItem();

                // Desmarcar todos los radio buttons antes de seleccionar los adecuados
                rbAdulto1.setSelected(false);
                rbAdulto2.setSelected(false);
                rb3eredad1.setSelected(false);
                rb3eredad2.setSelected(false);

                // Activar los radio buttons correspondientes según el formato seleccionado
                if ("Tradicional".equals(formatoSeleccionado)) {
                    rbAdulto1.setSelected(true);
                    rb3eredad1.setSelected(true);
                    rbAdulto2.setEnabled(false);
                    rb3eredad2.setEnabled(false);
                } else if ("3D".equals(formatoSeleccionado)) {
                    rbAdulto2.setSelected(true);
                    rb3eredad2.setSelected(true);
                    rbAdulto1.setEnabled(false);
                    rb3eredad1.setEnabled(false);
                } else {
                    // Si no se ha seleccionado un formato conocido, habilitar todas las opciones
                    rbAdulto1.setEnabled(true);
                    rbAdulto2.setEnabled(true);
                    rb3eredad1.setEnabled(true);
                    rb3eredad2.setEnabled(true);
                }
            }
        });
    }

    public void setVisible(boolean visible) {
        frame.setVisible(visible);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Pelicula pelicula = new Pelicula();
                pelicula.setVisible(true);
            }
        });
    }
}
