package Login;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Sala {
    private JButton btningresardato;
    private JButton btnPrimeCinema;
    private JButton btnEnviar;
    private JPanel panel1;
    private JComboBox<String> cmbHora;
    private JComboBox<String> cmbSala;
    private JTextField txtPelicula;
    private JComboBox<String> cmbSucursal;
    private JFrame frame;

    public Sala() {
        // Inicializar la ventana para Sala
        frame = new JFrame("Sala");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel1);
        frame.pack();
        frame.setLocationRelativeTo(null); // Centra la ventana

        // Acción del botón btningresardato
        btningresardato.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Botón Registro Sala presionado");
            }
        });

        // Acción del botón btnPrimeCinema
        btnPrimeCinema.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PrimeCinema primeCinema = new PrimeCinema();
                primeCinema.setVisible(true);
                frame.setVisible(false); // Ocultar la ventana actual
            }
        });

        // Acción del botón btnEnviar
        btnEnviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Verificar si todos los campos están llenos
                String pelicula = txtPelicula.getText().trim();
                String salaSeleccionada = (String) cmbSala.getSelectedItem();
                String horaSeleccionada = (String) cmbHora.getSelectedItem();
                String sucursalSeleccionada = (String) cmbSucursal.getSelectedItem();

                if (pelicula.isEmpty() || salaSeleccionada == null || salaSeleccionada.isEmpty() ||
                        horaSeleccionada == null || horaSeleccionada.isEmpty() ||
                        sucursalSeleccionada == null || sucursalSeleccionada.isEmpty()) {
                    // Mostrar mensaje si algún campo está vacío
                    JOptionPane.showMessageDialog(frame, "Favor llenar todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Mostrar mensaje si todos los campos están llenos
                    JOptionPane.showMessageDialog(frame, "Datos enviados correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
    }

    public void setVisible(boolean visible) {
        frame.setVisible(visible);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Sala sala = new Sala();
                sala.setVisible(true);
            }
        });
    }
}
